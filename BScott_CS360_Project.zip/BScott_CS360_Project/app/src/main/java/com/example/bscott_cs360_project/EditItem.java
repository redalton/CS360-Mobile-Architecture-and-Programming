package com.example.bscott_cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class EditItem extends AppCompatActivity {

    int id = -1;
    SQLiteDatabase mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
    }

    @Override
    protected void onResume(){
        super.onResume();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int value = extras.getInt("id");
            //The key argument here must match that used in the other activity
            id = value;
        }

        TextView idText = (TextView)findViewById(R.id.editIdVal);
        idText.setText(String.valueOf(id));
    }

    public void editItem(View view){
        TextView errorText = (TextView)findViewById(R.id.editError);

        //Get references to all of the items
        TextView nameText = (TextView)findViewById(R.id.editNameVal);
        TextView locationText = (TextView)findViewById(R.id.editLocVal);
        TextView qtyText = (TextView)findViewById(R.id.editQtyVal);

        String nameVal = nameText.getText().toString();
        String locationVal = locationText.getText().toString();
        String qtyValText = qtyText.getText().toString();
        int qtyVal = Integer.parseInt(qtyValText);
        //Check if any of the values are empty
        if(nameVal.equals("")){
            errorText.setText("Item name must not be blank!");
            return;
        }

        if(locationVal.equals("")){
            errorText.setText("Item location must not be blank!");
            return;
        }

        if(qtyValText.equals("")){
            errorText.setText("Item Qty must not be blank!");
            return;
        }

        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
        mydatabase.execSQL("UPDATE Inventory SET itemName = \'"+ nameVal + "\', itemLocation = \'" + locationVal + "\', qty = " + qtyVal + " WHERE id = " + id );

        Intent i = new Intent(EditItem.this,InventoryActivity.class);
        startActivity(i);
    }

    public void backToInventory(View view){
        Intent i = new Intent(EditItem.this,InventoryActivity.class);
        startActivity(i);
    }
}