package com.example.bscott_cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Prompt extends AppCompatActivity {

    SQLiteDatabase mydatabase;
    String user = " ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prompt);

        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);

    }

    protected void onResume(){
        super.onResume();

        TextView text = (TextView)findViewById(R.id.textView);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("User");
            //The key argument here must match that used in the other activity
            user = value;
        }

        Cursor resultSet = mydatabase.rawQuery("Select * from Users",null);
        boolean found = false;
        while(resultSet.moveToNext() && !found){
            if(user.compareTo(resultSet.getString(0))==0){
                if(resultSet.getString(2) == "TRUE"){
                    text.setText("You are already opted in, you may opt out at any time");
                }else{

                }
                found = true;
            }
        }
    }

    public void optIn(View view){
        Cursor resultSet = mydatabase.rawQuery("Select * from Users",null);
        boolean found = false;
        while(resultSet.moveToNext() && !found){
            if(user.compareTo(resultSet.getString(0))==0){
                mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
                mydatabase.execSQL("UPDATE Users SET TextOpt = 'TRUE' WHERE Username = \'" + user + "\'" );

                found = true;
            }
        }

        Intent i = new Intent(Prompt.this,InventoryActivity.class);
        i.putExtra("User", user);
        startActivity(i);
    }

    public void optOut(View view){
        Cursor resultSet = mydatabase.rawQuery("Select * from Users",null);
        boolean found = false;
        while(resultSet.moveToNext() && !found){
            if(user.compareTo(resultSet.getString(0))==0){
                mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
                mydatabase.execSQL("UPDATE Users SET TextOpt = 'FALSE' WHERE Username = \'" + user + "\'" );

                found = true;
            }
        }

        Intent i = new Intent(Prompt.this,InventoryActivity.class);
        i.putExtra("User", user);
        startActivity(i);
    }
}