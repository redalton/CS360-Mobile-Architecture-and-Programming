package com.example.bscott_cs360_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.app.ActionBar;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Space;
import android.widget.TableRow;
import android.widget.TextView;

public class InventoryActivity extends AppCompatActivity {

    String user = "";
    SQLiteDatabase mydatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS Inventory(id INTEGER,itemName VARCHAR, itemLocation VARCHAR, qty INTEGER);");
    }

    @Override
    protected void onResume(){
        super.onResume();

        TextView welcomeText = (TextView)findViewById(R.id.welcomeText);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("User");
            //The key argument here must match that used in the other activity
            user = value;
            welcomeText.setText("Welcome, " + user + "!");
        }
        //Load all the items from the database
        LoadFromDatabase();
    }

    public void goToAddPage(View view){
        Intent i = new Intent(InventoryActivity.this,AddItem.class);
        startActivity(i);
    }

    protected void LoadFromDatabase(){
        LinearLayout table = (LinearLayout)findViewById(R.id.linearLayout);


        //delete the old table
        for(int i = table.getChildCount()-1; i >= 0; i--){
            if(table.getChildAt(i).getId() != R.id.headerRow){
                table.removeViewAt(i);
            }else{
                Log.d("Project", "Not deleting header row");
            }
        }
        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
        Cursor resultSet = mydatabase.rawQuery("Select * from Inventory",null);
        while(resultSet.moveToNext()){
            Log.d("Project", "Fetched Item: " +
                    String.valueOf(resultSet.getInt(0)) + " - " +
                    resultSet.getString(1) + " - " +
                    resultSet.getString(2) + " - " +
                    String.valueOf(resultSet.getInt(3)));

            //Create a row for each
            TableRow row = (TableRow)new TableRow(InventoryActivity.this);
            row.setId(ViewCompat.generateViewId());


            //Add the ID from the database
            TextView idVal = (TextView)new TextView(InventoryActivity.this);
            idVal.setId(ViewCompat.generateViewId());
            int id = resultSet.getInt(0);
            idVal.setText(String.valueOf(id));
            row.addView(idVal, new TableRow.LayoutParams(150, 150));

            //Add the item name from the database
            TextView nameVal = (TextView)new TextView(InventoryActivity.this);
            nameVal.setId(ViewCompat.generateViewId());
            nameVal.setText(resultSet.getString(1));
            row.addView(nameVal, new TableRow.LayoutParams(350, 150));

            //Add the location from the database
            TextView locVal = (TextView)new TextView(InventoryActivity.this);
            locVal.setId(ViewCompat.generateViewId());
            locVal.setText(resultSet.getString(2));
            row.addView(locVal, new TableRow.LayoutParams(350, 150));

            //Add the quantity from the database
            TextView qtyVal = (TextView)new TextView(InventoryActivity.this);
            qtyVal.setId(ViewCompat.generateViewId());
            qtyVal.setText(String.valueOf(resultSet.getInt(3)));
            //qtyVal.setLayoutParams(new ViewGroup.LayoutParams(45, ViewGroup.LayoutParams.WRAP_CONTENT));
            row.addView(qtyVal, new TableRow.LayoutParams(125, 150));

            //Add the buttons
            Button editButton = (Button)new Button(InventoryActivity.this);
            editButton.setId(ViewCompat.generateViewId());
            editButton.setWidth(80);
            editButton.setHeight(40);
            editButton.setText("Edit");
            editButton.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    editRow(v, id);
                }
            });
            //editButton.setLayoutParams(new ViewGroup.LayoutParams(80, 40));
            row.addView(editButton, new TableRow.LayoutParams(275, 150));

            Button deleteButton = (Button)new Button(InventoryActivity.this);
            deleteButton.setWidth(40);
            deleteButton.setHeight(40);
            deleteButton.setText("X");
            //deleteButton.setLayoutParams(new ViewGroup.LayoutParams(40, 40));
            deleteButton.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    deleteRow(v, id);
                }
            });
            deleteButton.setId(ViewCompat.generateViewId());

            row.addView(deleteButton, new TableRow.LayoutParams(150, 150));

            TableRow.LayoutParams rowParams = new TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT
            );
            table.addView(row, rowParams);
        }
    }

    public void deleteRow(View view, int id){
        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
        mydatabase.execSQL("DELETE from Inventory where id = " + id);

        LoadFromDatabase();
    }

    public void editRow(View view, int id){
        Intent i = new Intent(InventoryActivity.this,EditItem.class);
        i.putExtra("id",id);
        startActivity(i);
    }

    public void goToOptIn(View view){
        Intent i = new Intent(InventoryActivity.this,Prompt.class);
        i.putExtra("User",user);
        startActivity(i);
    }
}