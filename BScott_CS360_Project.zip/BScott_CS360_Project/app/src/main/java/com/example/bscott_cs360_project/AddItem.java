package com.example.bscott_cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class AddItem extends AppCompatActivity {

    int id = 0;
    SQLiteDatabase mydatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
    }

    @Override
    protected void onResume(){
        super.onResume();

        updateId();
        TextView idText = (TextView)findViewById(R.id.idValue);
        idText.setText(String.valueOf(id));
    }

    protected void updateId(){
        //Iterate through the database and get the next ID

        Cursor resultSet = mydatabase.rawQuery("Select * from Inventory",null);
        if(resultSet.moveToLast()) {
            id = resultSet.getInt(0)+1;
        }else{
            id = 1;
        }
        Log.d("Project", "Id is "+id);
    }

    public void addNewItem(View view){
        TextView errorText = (TextView)findViewById(R.id.errorText);

        //Get references to all of the items
        TextView nameText = (TextView)findViewById(R.id.itemNameValue);
        TextView locationText = (TextView)findViewById(R.id.itemLocationValue);
        TextView qtyText = (TextView)findViewById(R.id.itemQtyValue);

        String nameVal = nameText.getText().toString();
        String locationVal = locationText.getText().toString();
        String qtyValText = qtyText.getText().toString();
        int qtyVal = Integer.parseInt(qtyValText);
        //Check if any of the values are empty
        if(nameVal.equals("")){
            errorText.setText("Item name must not be blank!");
            return;
        }

        if(locationVal.equals("")){
            errorText.setText("Item location must not be blank!");
            return;
        }

        if(qtyValText.equals("")){
            errorText.setText("Item Qty must not be blank!");
            return;
        }

        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
        mydatabase.execSQL("INSERT INTO Inventory VALUES (\'" + id + "\',\'" + nameVal + "\',\'" + locationVal + "\',\'" + qtyVal +"\')");

        Intent i = new Intent(AddItem.this,InventoryActivity.class);
        startActivity(i);
    }

    public void backToInventory(View view){
        Intent i = new Intent(AddItem.this,InventoryActivity.class);
        startActivity(i);
    }
}