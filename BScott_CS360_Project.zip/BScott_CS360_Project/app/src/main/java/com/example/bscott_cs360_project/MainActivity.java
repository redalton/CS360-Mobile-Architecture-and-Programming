package com.example.bscott_cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;

    SQLiteDatabase mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mydatabase = openOrCreateDatabase("inventoryDB",MODE_PRIVATE,null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS Users(Username VARCHAR,Password VARCHAR, TextOpt VARCHAR);");

    }

    public void Login(View view){
        TextView usernameView = (TextView)findViewById(R.id.username);
        String username = usernameView.getText().toString();

        TextView passwordView = (TextView)findViewById(R.id.password);
        String password = passwordView.getText().toString();

        TextView warning = (TextView)findViewById(R.id.warningText);

        boolean found = false;
        Cursor resultSet = mydatabase.rawQuery("Select * from Users",null);
        while(resultSet.moveToNext() && !found){
            Log.d("Project", "User DB: " + resultSet.getString(0) + ", " + resultSet.getString(1) + " -- compared to: " + username + ", " + password);
            if(username.compareTo(resultSet.getString(0)) == 0 && password.compareTo(resultSet.getString(1)) == 0){
                Log.d("Project","Logged in!");
                found = true;
                //Logged in
                Intent i = new Intent(MainActivity.this,InventoryActivity.class);
                i.putExtra("User", username);
                startActivity(i);
            }
            resultSet.moveToNext();
        }

        if(!found){
            warning.setText("Username or password is incorrect");
        }

    }

    public void SignUp(View view){
        TextView usernameView = (TextView)findViewById(R.id.username);
        String username = usernameView.getText().toString();

        TextView passwordView = (TextView)findViewById(R.id.password);
        String password = passwordView.getText().toString();

        TextView warning = (TextView)findViewById(R.id.warningText);

        Cursor resultSet = mydatabase.rawQuery("Select * from Users",null);
        boolean found = false;
        while(resultSet.moveToNext() && !found){
            Log.d("Project", "User DB: " + resultSet.getString(0) + ", " + resultSet.getString(1) + " -- compared to: " + username + ", " + password);
            if(username.compareTo(resultSet.getString(0))==0){
                found = true;
                //That user already exists
                warning.setText("A user with that username already exists!");
                break;
            }
            resultSet.moveToNext();
        }

        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS Users(Username VARCHAR,Password VARCHAR);");
        mydatabase.execSQL("INSERT INTO Users VALUES (\'" + username + "\',\'" + password +"\',"+"FALSE)");
    }
}